# Shared foundations

*Learn these at a working level in every field. The depth you need will grow with your specialization.*

**Four-stage sequence**

1. **Write and reason:** programming fundamentals; problem solving and logic
2. **Organize and analyze:** data structures and algorithms; efficiency and essential math
3. **Understand computers:** hardware and operating systems; networks and data storage
4. **Build responsibly:** Git, testing and documentation; security, privacy and accessibility

## A suggested learning sequence

Start programming and solving small problems. Add data structures, efficiency, and mathematics. Study how programs use hardware, operating systems, networks, and databases. Practice testing, Git, security, and responsible computing throughout.

## A useful first language

Choose Python if you are undecided. You can also start directly with your target field: JavaScript for web development, Kotlin for Android, or C for embedded systems. Learn one language well enough to build and debug a small application.

## Foundation project

Build a command line expense tracker. Store data in SQLite, validate inputs, handle errors, write tests, and track changes with Git. Then add a small HTTP API to practice networking and access control.

## The foundations checklist

| Foundation | What to know |
|---|---|
| Programming | Variables, types, conditions, loops, functions, collections, modules, exceptions, basic object-oriented programming. |
| Computational thinking | Decomposition, abstraction, logical reasoning, pseudocode, edge cases, debugging. |
| Data structures | Arrays, strings, hash maps, stacks, queues, trees; basic graph representations. |
| Algorithms and efficiency | Searching, sorting, recursion, Big O, time and space tradeoffs. |
| Computer fundamentals | Binary and data representation, CPU, RAM, storage, compilation versus interpretation, program execution. |
| Operating systems | Files, processes, threads, permissions, memory, terminal navigation and commands. |
| Networking | IP addresses, DNS, ports, HTTP/HTTPS, requests and responses, client-server communication. |
| Data and databases | Tables, keys, relationships, basic SQL, joins, JSON, CSV, basic schema design. |
| Software practices | Readable code, modular design, Git, tests, documentation, dependency and package management. |
| Security | Authentication versus authorization, input validation, secrets, safe data handling, dependency updates. |
| Mathematics | Boolean logic, sets, functions, basic discrete mathematics and probability. |
| Responsible computing | Privacy, accessibility, ethical use, system limitations and effects of software on people. |

Starter toolkit: one editor, your language runtime, its package manager, a terminal, Git and GitHub, a debugger, and a test framework. Add other tools when a project needs them.

---
Ready to specialize? Pick a field in the [README](README.md).
