# Computer Science Learning Guide

*Shared foundations and career learning paths*

Build a working foundation, choose one field, and learn its languages and tools through complete projects. This guide brings the shared basics and the specialization roadmaps together, one file per field.

**How to use these files:** start with [Shared foundations](00-shared-foundations.md), pick one field below, and learn its languages and tools through complete projects. Tools are starting choices; alternatives are separate paths, not extra requirements.

Frontend, backend and full stack are separate web paths within software development; full stack combines the other two. These practical career groups overlap and are not a formal partition of computer science.

## Field map

- **Shared foundations** — [00-shared-foundations.md](00-shared-foundations.md)
  - Intelligence and theory
    - [AI and Machine Learning](01-ai-and-machine-learning.md)
    - [Data Science and Data Engineering](09-data-science-and-data-engineering.md)
    - [Theoretical Computer Science](14-theoretical-computer-science.md)
  - Software development
    - [Frontend Development](03-frontend-development.md)
    - [Backend Development](04-backend-development.md)
    - [Full Stack Development](05-full-stack-development.md)
    - [Mobile Development](06-mobile-development.md)
    - [Desktop Development](07-desktop-development.md)
    - [Game Development](08-game-development.md)
  - Systems and infrastructure
    - [Cybersecurity](02-cybersecurity.md)
    - [Cloud and DevOps](10-cloud-and-devops.md)
    - [Systems and Embedded Development](11-systems-and-embedded-development.md)
    - [Networking](12-networking.md)
    - [Computer Graphics and AR VR](13-computer-graphics-and-ar-vr.md)

## Which field fits you?

Not sure where to start? Match what you enjoy to a field, then try its first project before committing. Fields overlap, and you can change direction later because the foundations carry over.

| If you enjoy… | Consider | Try this first |
|---|---|---|
| Teaching computers to learn from data | [AI and Machine Learning](01-ai-and-machine-learning.md) | Train a simple classifier on a public dataset. |
| Finding patterns, answering questions with data | [Data Science and Data Engineering](09-data-science-and-data-engineering.md) | Analyze a CSV in a notebook and chart one finding. |
| Breaking things to understand how they fail | [Cybersecurity](02-cybersecurity.md) | Complete a beginner web security lab, then write up the fix. |
| Designing and building what users see and click | [Frontend Development](03-frontend-development.md) | Build a responsive page and add interactivity with JavaScript. |
| Designing the data, rules and APIs behind an app | [Backend Development](04-backend-development.md) | Build a small REST API backed by a database. |
| Wanting to build a whole product end to end | [Full Stack Development](05-full-stack-development.md) | Build a small app with an interface, an API and a database. |
| Building apps for phones | [Mobile Development](06-mobile-development.md) | Build a one-screen app that stores a list locally. |
| Polished tools that run on a computer | [Desktop Development](07-desktop-development.md) | Build a small notes or timer window app. |
| Making interactive worlds and mechanics | [Game Development](08-game-development.md) | Make a playable 2D game with one mechanic. |
| Keeping services running and automating releases | [Cloud and DevOps](10-cloud-and-devops.md) | Containerize an app and add a CI workflow. |
| Low-level control of memory, hardware and timing | [Systems and Embedded Development](11-systems-and-embedded-development.md) | Write a tiny shell in C, or blink an LED from a board. |
| Understanding how machines communicate | [Networking](12-networking.md) | Capture and inspect a web request in Wireshark. |
| Visuals, 3D, shaders and immersive spaces | [Computer Graphics and AR VR](13-computer-graphics-and-ar-vr.md) | Draw and light a 3D object. |
| Proofs, puzzles and the limits of computation | [Theoretical Computer Science](14-theoretical-computer-science.md) | Prove a sorting algorithm correct and time it. |

Still undecided? Complete the foundation project, pick the two fields that sound most interesting, spend a weekend on each first project, and keep the one you want to continue.

## Putting the guide into practice

**Foundation ready** Write and debug small programs, use Git, query a database and explain basic HTTP, memory and permissions.

**First project complete** Connect your stack. Handle errors, validate inputs and document how to run the result.

**Independent practice** Build a second project with fewer tutorial instructions. Explain your choices and investigate failures yourself.

**Deeper specialization** Add advanced tools when a project exposes a real need. Revisit mathematics and systems topics as needed.

Learning sequences and stack choices are recommendations. The linked documentation provides further instruction; it does not prescribe this entire guide. Tools evolve, while the underlying foundations remain useful.
